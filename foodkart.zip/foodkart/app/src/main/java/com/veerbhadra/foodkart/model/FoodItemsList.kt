package com.veerbhadra.foodkart.model

class FoodItemsList(
    val foodId: String,
    val foodName: String,
    val foodCost: String
)