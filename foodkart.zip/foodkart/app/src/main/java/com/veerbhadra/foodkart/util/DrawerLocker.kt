package com.veerbhadra.foodkart.util

interface DrawerLocker {
    fun setDrawerEnabled(enabled: Boolean)
}