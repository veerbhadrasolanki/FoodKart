package com.veerbhadra.foodkart.activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.veerbhadra.foodkart.R

class ProfileActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)
    }
}